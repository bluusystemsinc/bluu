//
//  DeviceListViewController.h
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceListViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
}

@property(nonatomic,retain)NSMutableArray *deviceList;
@property(nonatomic,retain)IBOutlet UIBarButtonItem *editButton; 

@end
