//
//  LFHardwareConnector.h
//  Collector_A2_Demo
//
//  Created by apple on 12-11-29.
//  Copyright (c) 2012年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LFSensorDefine.h"
typedef enum
{
    CONNECTOR_NORMAL_STATE=0x01,
    CONNECTOR_PAIRING_STATE=0x02,
    CONNECTOR_ANY_STATE = CONNECTOR_NORMAL_STATE|CONNECTOR_PAIRING_STATE
}CONNECTOR_STATE;



@protocol LFHardwareConnectorDelegate <NSObject>

@optional
-(NSSet*)setOfDownloadInfoTypesForSensor:(LFHardwareSensor *)sensor;
-(id)hardwareConnectorGetDownloadInfoForSensor:(LFHardwareSensor *)sensor ofInfoType:(LF_DOWNLOAD_INFO_TYPE)infoType;

-(void)hardwareConnectorDidDownloadInfoForSensor:(LFHardwareSensor *)sensor ofInfoType:(LF_DOWNLOAD_INFO_TYPE)infoType withResult:(BOOL)result;
@required
-(void)hardwareConnectorDiscoveredSensor:(LFHardwareSensor*)sensor;
-(void)hardwareConnectorPairedSensor:(LFHardwareSensor*)sensor withState:(BOOL)state;
-(void)hardwareConnectorReceiveWeightMeasurementData:(WeightData*)data;
-(void)hardwareConnectorReceivePedometerMeasurementData:(PedometerData*)data;
-(void)hardwareConnectorReceiveBloodPressureMeasurementData:(BloodPressureData *)data;

@end
@interface LFHardwareConnector : NSObject




@property(nonatomic,readonly)BOOL isBLEEnable;
@property(nonatomic,readonly)CONNECTOR_STATE currentState;
@property(nonatomic,readonly)BOOL hasConnectedSensor;
@property(nonatomic,assign)id<LFHardwareConnectorDelegate> delegate;

-(void)setConnectorState:(CONNECTOR_STATE)state;
-(void)enalbeSensorType:(LF_SENSOR_TYPE)sensorType;
-(void)disableSensorType:(LF_SENSOR_TYPE)sensorType;
-(void)enableAllSupportedSernsorType;
-(NSSet*)supportedSensorTypes;
-(void)startScanning;
-(void)cancelScanning;
-(BOOL)pairWithHardwareSensor:(LFHardwareSensor*)sensor;
-(BOOL)enqueueHardwareSensor:(LFHardwareSensor*)sensor;
+(LFHardwareConnector*)shareConnector;
@end
