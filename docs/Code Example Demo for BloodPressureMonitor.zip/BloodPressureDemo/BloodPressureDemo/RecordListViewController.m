//
//  RecordListViewController.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "RecordListViewController.h"
#import "LFSensorDefine.h"
#import "LFBloodPressureDataStore.h"
@interface RecordListViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *table;
    
}
@property(nonatomic,retain)NSMutableArray *recordList;

@end

@implementation RecordListViewController
@synthesize recordList;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)dealloc
{
    [table release];
    [recordList release];
    [super dealloc];
}
- (void)viewDidLoad
{
    self.recordList = [NSMutableArray arrayWithArray:[[LFBloodPressureDataStore shareBloodPressureDataStore] getAllBloodPressureDataRecords]];
    table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

-(void)customTableViewCell:(UITableViewCell*)cell
{
    UILabel *dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 250, 20)];
    dateLabel.tag = 100;
    UILabel *memberIdLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 20, 250, 20)];
    memberIdLabel.tag = 101;
    //UILabel *deviceIdLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 40, 250, 20)];
    //deviceIdLabel.tag = 102;
    UILabel *firstLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 40, 120, 20)];
    firstLabel.tag = 103;
    UILabel *secondLabel = [[UILabel alloc]initWithFrame:CGRectMake(130, 40, 120, 20)];
    secondLabel.tag = 104;
    UILabel *thirdLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 60, 150, 20)];
    thirdLabel.tag = 105;
    UILabel *fourthLabel = [[UILabel alloc]initWithFrame:CGRectMake(160, 60, 150, 20)];
    fourthLabel.tag = 106;
    
    [cell addSubview:dateLabel];
    [cell addSubview: memberIdLabel];
    //[cell addSubview:deviceIdLabel];
    [cell addSubview:firstLabel];
    [cell addSubview:secondLabel];
    [cell addSubview:thirdLabel];
    [cell addSubview:fourthLabel];
    
    [dateLabel release];
    [memberIdLabel release];
    //[deviceIdLabel release];
    [firstLabel release];
    [secondLabel release];
    [thirdLabel release];
    [fourthLabel release];
    
}

-(void)loadBloodPressureIn:(UITableViewCell*)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    UILabel *label = (UILabel*)[cell viewWithTag:100];
    BloodPressureData *bloodPressure = [recordList objectAtIndex:indexPath.row];
    label.text = [NSString stringWithFormat:@"Date: %@",bloodPressure.date];
    label =(UILabel*)[cell viewWithTag:101];
    label.text = [NSString stringWithFormat:@"Device: %@",bloodPressure.deviceId];
    //label = (UILabel*)[cell viewWithTag:102];
    //label.text = [NSString stringWithFormat:@"MemberId:%@",bloodPressure.memberId];
    
    
    if ([bloodPressure.unit isEqualToString:@"kpa"]) {
        
        label = (UILabel *)[cell viewWithTag:103];
        label.text = [NSString stringWithFormat:@"S: %1.1f%@",bloodPressure.systolic,bloodPressure.unit];
        label = (UILabel*)[cell viewWithTag:104];
        label.text = [NSString stringWithFormat:@"D: %1.1f%@",bloodPressure.diastolic,bloodPressure.unit];
    }else
    {
        label = (UILabel *)[cell viewWithTag:103];
        label.text = [NSString stringWithFormat:@"S: %1.0f%@",bloodPressure.systolic,bloodPressure.unit];
        label = (UILabel*)[cell viewWithTag:104];
        label.text = [NSString stringWithFormat:@"D: %1.0f%@",bloodPressure.diastolic,bloodPressure.unit];
    }
    label = (UILabel*)[cell viewWithTag:105];
    label.text = [NSString stringWithFormat:@"Pluse: %1.0f",bloodPressure.pluseRate];
    label = (UILabel*)[cell viewWithTag:106];
    label.text = [NSString stringWithFormat:@"UserNo: %d",bloodPressure.userNo];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark TableView Delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100.0;
}

-(NSIndexPath*)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}
#pragma mark TableView DataSource

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [recordList count];
    
    
    //return 1;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *memberCellIdentifier = @"recordCellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:memberCellIdentifier];
    if (!cell) {
        
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:memberCellIdentifier]autorelease];
        [cell.textLabel setFont:[UIFont systemFontOfSize:14.0]];
        [self customTableViewCell:cell];
    }
    
    [self loadBloodPressureIn:cell forRowAtIndexPath:indexPath];
    
    
    return cell;
}
@end
