//
//  LFDeviceDataStore.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "LFDeviceDataStore.h"
#import "LFManagedDataContext.h"
#import "LFCoreDataDefine.h"
#import "LFSensorDefine.h"
@implementation LFDeviceDataStore

static LFDeviceDataStore *shareDeviceDataStore = nil;

+(LFDeviceDataStore *)shareDeviceDataStore
{
    
    if (!shareDeviceDataStore) {
        
        shareDeviceDataStore = [[LFDeviceDataStore alloc] init];
    }
    return shareDeviceDataStore;

}

-(NSArray *)deviceInfosFromManagedDeviceObject:(NSArray *)managedDeviceObjectList
{
    NSMutableArray *deviceInfoList = nil;
    if ([managedDeviceObjectList count]>0) {
        
        deviceInfoList = [[[NSMutableArray alloc] init] autorelease];
        for (LFManagedHardwareSensor *managedDevice in managedDeviceObjectList) {
            
            LFHardwareSensor *sensor = [[LFHardwareSensor alloc] init];
            sensor.deviceId = managedDevice.deviceId;
            sensor.deviceSn = managedDevice.deviceSn;
            sensor.sensorType = managedDevice.sensorType;
            sensor.modelNumber = managedDevice.modelNumber;
            sensor.sensorName  = managedDevice.sensorName;
            sensor.pairSignature = managedDevice.pairSignature;
            sensor.password = managedDevice.password;
            sensor.supportDownloadInfoFeature = managedDevice.supportDownloadInfoFeature;
            sensor.maxUserQuantity = managedDevice.maxUserQuantity;
            sensor.softwareVersion = managedDevice.softwareVersion;
            sensor.hardwareVersion = managedDevice.hardwareVersion;
            sensor.firmwareVersion = managedDevice.firmwareVersion;
            sensor.manufactureName = managedDevice.manufactureName;
            sensor.systemId = managedDevice.systemId;
            [deviceInfoList addObject:sensor];
            [sensor release];
        }
    }
    
    return deviceInfoList;
}

-(void)initialManagedDeviceObject:(LFManagedHardwareSensor *)managedDevice withDeviceInfo:(LFHardwareSensor *)sensor
{
    managedDevice.deviceId = sensor.deviceId;
    managedDevice.deviceSn = sensor.deviceSn;
    managedDevice.sensorType = sensor.sensorType;
    managedDevice.modelNumber = sensor.modelNumber;
    managedDevice.sensorName  = sensor.sensorName;
    managedDevice.pairSignature = sensor.pairSignature;
    managedDevice.password = sensor.password;
    managedDevice.supportDownloadInfoFeature = sensor.supportDownloadInfoFeature;
    managedDevice.maxUserQuantity = sensor.maxUserQuantity;
    managedDevice.softwareVersion = sensor.softwareVersion;
    managedDevice.hardwareVersion = sensor.hardwareVersion;
    managedDevice.firmwareVersion = sensor.firmwareVersion;
    managedDevice.manufactureName = sensor.manufactureName;
    managedDevice.systemId = sensor.systemId;
}

-(NSArray *)fetchManagedDeviceObjectWithSignature:(NSInteger)signature
{
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    NSManagedObjectModel *currentManagedObjectModel = [[currentManagedObjectContext persistentStoreCoordinator] managedObjectModel];
    NSEntityDescription *deviceEntity = [[currentManagedObjectModel entitiesByName] objectForKey:@"device"];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:deviceEntity];
    NSExpression *leftKey = [NSExpression expressionForKeyPath:@"pairSignature"];
    NSExpression *rightVariable = [NSExpression expressionForVariable:@"SIGNATURE"];
    NSPredicate *devicePredicateTemplate = [NSComparisonPredicate predicateWithLeftExpression:leftKey rightExpression:rightVariable modifier:NSDirectPredicateModifier type:NSEqualToPredicateOperatorType options:NSCaseInsensitivePredicateOption];
    NSPredicate *runtimePredicate = [devicePredicateTemplate predicateWithSubstitutionVariables:[NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:signature] forKey:@"SIGNATURE"]];
    [request setPredicate:runtimePredicate];
    NSError *error = nil;
    NSArray *deviceObjectList = [currentManagedObjectContext executeFetchRequest:request error:&error];
    if (error) {
        
        NSLog(@"Fail to get device object with error:%@",[error description]);
    }
    NSAssert([deviceObjectList count]<=1, @"It may be something wrong with more than 1 device  have the same deviceId");
    [request release];
    return deviceObjectList ;
}

-(LFHardwareSensor *)getSpecificDeviceInfoWithSignature:(NSUInteger)signature
{
    NSArray *managedDeviceList = [self fetchManagedDeviceObjectWithSignature:signature];
    NSArray *sensorList = [self deviceInfosFromManagedDeviceObject:managedDeviceList];
    
    return [sensorList lastObject];
}

-(NSArray *)getAllDeviceInfo
{
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    NSManagedObjectModel *currentManagedObjectModel = [[currentManagedObjectContext persistentStoreCoordinator] managedObjectModel];
    NSEntityDescription *deviceEntity = [[currentManagedObjectModel entitiesByName] objectForKey:@"device"];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:deviceEntity];
    NSError *error = nil;
    NSArray *deviceObjectList = [currentManagedObjectContext executeFetchRequest:request error:&error];
    if (error) {
        
        NSLog(@"Fail to get device object with error:%@",[error description]);
    }
    [request release];
    NSArray *sensorList = [self deviceInfosFromManagedDeviceObject:deviceObjectList];
    
    return sensorList;
    
}

-(BOOL)insertNewDeviceWithDeviceInfo:(LFHardwareSensor *)sensor
{
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    LFManagedHardwareSensor *managedDevice = [NSEntityDescription insertNewObjectForEntityForName:@"device" inManagedObjectContext:currentManagedObjectContext ];
    [self initialManagedDeviceObject:managedDevice withDeviceInfo:sensor];
    NSError *error = nil;
    BOOL result = [currentManagedObjectContext save:&error];
    if (!result) {
        
        NSLog(@"Fail to insert managed device with error :%@",[error description]);
        [currentManagedObjectContext rollback];
    }
    
    return result;
}

-(BOOL)updateDeviceWithDeviceInfo:(LFHardwareSensor *)sensor
{
    BOOL result = NO;
    LFManagedHardwareSensor *managedDevice = [[self fetchManagedDeviceObjectWithSignature:sensor.pairSignature] lastObject];
    if (managedDevice) {
        [self initialManagedDeviceObject:managedDevice withDeviceInfo:sensor];
        NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
        NSError *error = nil;
        result = [currentManagedObjectContext save:&error];
        if (!result) {
            NSLog(@"Fail to update managed Device with error:%@",[error description]);
            [currentManagedObjectContext rollback];
        }
    
    }
    return result;
}

-(BOOL)deleteDeviceWithSignature:(NSUInteger)signature
{
    LFManagedHardwareSensor *managedDevice = [[self fetchManagedDeviceObjectWithSignature:signature] lastObject];
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    NSError *error = nil;
    [currentManagedObjectContext deleteObject:managedDevice];
    BOOL result = [currentManagedObjectContext save:&error];
    if (!result) {
        
        NSLog(@"Fail to delete managed device with error:%@",[error description]);
        [currentManagedObjectContext rollback];
    }
    
    return result;

}

@end
