//
//  DeviceListViewController.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "DeviceListViewController.h"
#import "LFDeviceDataStore.h"
#import "LFSensorDefine.h"
#import "DesignTableViewCell.h"
@interface DeviceListViewController ()
{
    UITableView *table;
    
}
@end

@implementation DeviceListViewController
@synthesize deviceList,editButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)dealloc
{
    [table release];
    [deviceList release];
    [editButton release];
    [super dealloc];
}

-(void)editButtonTap:(id)sender
{
    if (table.editing) {
        
        [table setEditing:NO animated:YES];
        [editButton setTitle:@"edit"];
    }else
    {
        [table setEditing:YES animated:YES];
        [editButton setTitle:@"done"];
    }
    
}


-(IBAction)backButtonTap:(id)sender
{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad
{
    self.deviceList = [NSMutableArray arrayWithArray:[[LFDeviceDataStore shareDeviceDataStore] getAllDeviceInfo]];
    //CGSize size =  self.navigationController.navigationBar.frame.size;
    table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    [editButton setTitle:@"edit"];
    [editButton setAction:@selector(editButtonTap:)];
    [editButton setTarget:self];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark TableView Delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120.0;
}

-(NSIndexPath*)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}



#pragma mark TableView DataSource

-(void)loadDeviceInfoIn:(UITableViewCell*)cell forRowAtIndexPath:(NSIndexPath*)indexPath
{
    UILabel *label = (UILabel*)[cell.contentView viewWithTag:100];
    LFHardwareSensor *sensor = [deviceList objectAtIndex:indexPath.row];
    label.text = [NSString stringWithFormat:@"Name: %@",sensor.sensorName];
    label =(UILabel*)[cell.contentView viewWithTag:101];
    label.text = [NSString stringWithFormat:@"Device ID: %@",sensor.deviceId];
    label = (UILabel*)[cell.contentView viewWithTag:102];
    label.text = [NSString stringWithFormat:@"Model Number: %@",sensor.modelNumber];
    label = (UILabel*)[cell.contentView viewWithTag:104];
    
    label.text = [NSString stringWithFormat:@"Type: BLP"];
    
    label = (UILabel*)[cell.contentView viewWithTag:105];
    label.text = [NSString stringWithFormat:@"Max.User: %d",sensor.maxUserQuantity];
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (deviceList.count==0) {
        
        editButton.enabled = NO;
    }else
    {
        editButton.enabled = YES;
    }
    return [deviceList count];
    
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *memberCellIdentifier = @"recordCellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:memberCellIdentifier];
    if (!cell) {
        
        cell = [[[DesignTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:memberCellIdentifier]autorelease];
        
        
    }
    
    [self loadDeviceInfoIn:cell forRowAtIndexPath:indexPath];
    return cell;
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    LFHardwareSensor *sensor = [deviceList objectAtIndex:indexPath.row];
    [[LFDeviceDataStore shareDeviceDataStore] deleteDeviceWithSignature:sensor.pairSignature];
    [deviceList  removeObjectAtIndex:indexPath.row];
    
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}
@end
