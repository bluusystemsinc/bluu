//
//  LFCoreDataDefine.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "LFCoreDataDefine.h"

@implementation LFCoreDataDefine

@end

@implementation LFManagedHardwareSensor

@dynamic deviceId;
@dynamic deviceSn;
@dynamic preparePair;
@dynamic sensorType;
@dynamic modelNumber;
@dynamic sensorName;
@dynamic pairSignature;
@dynamic password;
@dynamic supportDownloadInfoFeature;
@dynamic maxUserQuantity;
@dynamic softwareVersion;
@dynamic hardwareVersion;
@dynamic firmwareVersion;
@dynamic manufactureName;
@dynamic systemId;

@end

@implementation ManagedBloodPressureData

@dynamic date;
@dynamic deviceId;
@dynamic userNo;
@dynamic diastolic;
@dynamic systolic;
@dynamic pluseRate;
@dynamic battery;
@dynamic unit;
@end