//
//  LFCoreDataDefine.h
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
@interface LFCoreDataDefine : NSObject

@end

@interface LFManagedHardwareSensor : NSManagedObject

@property(nonatomic,retain)NSString *deviceId;
@property(nonatomic,retain)NSString *deviceSn;
@property(nonatomic,assign)BOOL preparePair;
@property(nonatomic,assign)NSInteger sensorType;
@property(nonatomic,retain)NSString *modelNumber;
@property(nonatomic,retain)NSString *sensorName;
@property(nonatomic,assign)NSUInteger pairSignature;
@property(nonatomic,assign)NSUInteger password;
@property(nonatomic,assign)NSUInteger supportDownloadInfoFeature;
@property(nonatomic,assign)NSInteger maxUserQuantity;
@property(nonatomic,retain)NSString *softwareVersion;
@property(nonatomic,retain)NSString *hardwareVersion;
@property(nonatomic,retain)NSString *firmwareVersion;
@property(nonatomic,retain)NSString *manufactureName;
@property(nonatomic,retain)NSString *systemId;
@end

@interface ManagedBloodPressureData : NSManagedObject

@property(nonatomic,retain)NSString *date;
@property(nonatomic,retain)NSString *deviceId;
@property(nonatomic)NSInteger userNo;
@property(nonatomic,assign)double systolic;
@property(nonatomic,assign)double diastolic;
@property(nonatomic,assign)double pluseRate;
@property(nonatomic,retain)NSString *unit;
@property(nonatomic,assign)NSInteger battery;
@end