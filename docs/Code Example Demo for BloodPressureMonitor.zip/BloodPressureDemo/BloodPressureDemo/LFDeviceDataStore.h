//
//  LFDeviceDataStore.h
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LFHardwareSensor;
@interface LFDeviceDataStore : NSObject


+(LFDeviceDataStore *)shareDeviceDataStore;
-(LFHardwareSensor *)getSpecificDeviceInfoWithSignature:(NSUInteger)signature;
-(NSArray *)getAllDeviceInfo;
-(BOOL)insertNewDeviceWithDeviceInfo:(LFHardwareSensor *)sensor;
-(BOOL)updateDeviceWithDeviceInfo:(LFHardwareSensor *)sensor;
-(BOOL)deleteDeviceWithSignature:(NSUInteger)signature;

@end
