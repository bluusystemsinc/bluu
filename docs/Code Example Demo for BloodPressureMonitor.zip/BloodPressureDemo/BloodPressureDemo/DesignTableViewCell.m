//
//  DesignTableViewCell.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "DesignTableViewCell.h"

@implementation DesignTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self customTableViewCell];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)customTableViewCell
{
    
    UILabel * deviceIdLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 250, 20)];
    deviceIdLabel.tag = 100;
    UILabel *softwareLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 20, 250, 20)];
    softwareLabel.tag = 101;
    UILabel *hardwareLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 40, 250, 20)];
    hardwareLabel.tag = 102;
    UILabel *firstLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 60, 100, 20)];
    firstLabel.tag = 103;
    UILabel *secondLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 60, 250, 20)];
    secondLabel.tag = 104;
    UILabel *thirdLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 80, 200, 20)];
    thirdLabel.tag = 105;
    UILabel *fourthLabel = [[UILabel alloc]initWithFrame:CGRectMake(90, 80, 200, 20)];
    fourthLabel.tag = 106;
    
    [self.contentView addSubview:deviceIdLabel];
    [self.contentView addSubview: softwareLabel];
    [self.contentView addSubview:hardwareLabel];
    [self.contentView addSubview:secondLabel];
    [self.contentView addSubview:thirdLabel];
    
    [deviceIdLabel release];
    [softwareLabel release];
    [hardwareLabel release];
    [firstLabel release];
    [secondLabel release];
    [thirdLabel release];
    [fourthLabel release];
    
}
@end
