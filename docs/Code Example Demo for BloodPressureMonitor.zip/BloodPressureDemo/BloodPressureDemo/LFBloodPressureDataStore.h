//
//  LFBloodPressureDataStore.h
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BloodPressureData;
@interface LFBloodPressureDataStore : NSObject

+(LFBloodPressureDataStore *)shareBloodPressureDataStore;
-(NSArray *)getAllBloodPressureDataRecords;
-(BOOL)insertNewBloodPressureWithBloodPressureData:(BloodPressureData*)bloodPressure;
-(BOOL)deleteAllBloodPressureDataRecords;
@end
