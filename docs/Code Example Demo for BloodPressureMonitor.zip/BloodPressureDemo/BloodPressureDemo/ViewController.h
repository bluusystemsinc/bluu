//
//  ViewController.h
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic, retain)IBOutlet UITableView *sensorTable;
@property(nonatomic, retain)IBOutlet UILabel *dateLabel;
@property(nonatomic, retain)IBOutlet UILabel *typeLabel;
@property(nonatomic, retain)IBOutlet UILabel *dialLabel;
@property(nonatomic, retain)IBOutlet UILabel *label1;
@property(nonatomic, retain)IBOutlet UILabel *label2;
@property(nonatomic, retain)IBOutlet UIBarButtonItem *deviceListButton;
@end
