//
//  LFBloodPressureDataStore.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "LFBloodPressureDataStore.h"
#import "LFManagedDataContext.h"
#import "LFCoreDataDefine.h"
#import "LFSensorDefine.h"
@implementation LFBloodPressureDataStore

static LFBloodPressureDataStore *shareBloodPressureDataStore;
+(LFBloodPressureDataStore *)shareBloodPressureDataStore
{
    
    if (!shareBloodPressureDataStore) {
        
        shareBloodPressureDataStore = [[LFBloodPressureDataStore alloc] init];
    }
    
    return shareBloodPressureDataStore;
}

-(NSArray *)bloodPressureMeasurementsFromManagedBloodPressureData:(NSArray *)managedBloodPressureList
{
    NSMutableArray *bloodPressureMeasurementList = nil;
    if ([managedBloodPressureList count]>0) {
        
        bloodPressureMeasurementList = [[[NSMutableArray alloc] init] autorelease];
        for (ManagedBloodPressureData *managedBloodPressure in managedBloodPressureList) {
            
            BloodPressureData *bloodPressure = [[BloodPressureData alloc] init];
            bloodPressure.deviceId = managedBloodPressure.deviceId;
            bloodPressure.date = managedBloodPressure.date;
            bloodPressure.userNo = managedBloodPressure.userNo;
            bloodPressure.systolic = managedBloodPressure.systolic;
            bloodPressure.diastolic = managedBloodPressure.diastolic;
            bloodPressure.pluseRate = managedBloodPressure.pluseRate;
            bloodPressure.unit = managedBloodPressure.unit;
            bloodPressure.battery = managedBloodPressure.battery;
            [bloodPressureMeasurementList addObject:bloodPressure];
            [bloodPressure release];
        }
    }
    
    return bloodPressureMeasurementList;
}

-(void)initialManagedBloodPressureData:(ManagedBloodPressureData *)managedBloodPressure withBloodPressureData:(BloodPressureData *)bloodPressure
{
    managedBloodPressure.deviceId = bloodPressure.deviceId;
    managedBloodPressure.date = bloodPressure.date;
    managedBloodPressure.userNo = bloodPressure.userNo;
    managedBloodPressure.systolic = bloodPressure.systolic;
    managedBloodPressure.diastolic = bloodPressure.diastolic;
    managedBloodPressure.pluseRate = bloodPressure.pluseRate;
    managedBloodPressure.unit = bloodPressure.unit;
    managedBloodPressure.battery = bloodPressure.battery;
}

-(NSArray *)getAllBloodPressureDataRecords
{
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    NSManagedObjectModel *currentManagedObjectModel = [[currentManagedObjectContext persistentStoreCoordinator] managedObjectModel];
    NSEntityDescription *bloodPressureEntity = [[currentManagedObjectModel entitiesByName]objectForKey:@"bloodPressureMeasurement"];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];
    [request setEntity:bloodPressureEntity];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSError *error = nil;
    NSArray *managedBloodPressureMeasurementList = [currentManagedObjectContext executeFetchRequest:request error:&error];
    [request release];
    if (error) {
        
        NSLog(@"Fail to fetch bloodPressure measurement of member with error:%@",[error description]);
    }
    NSArray *bloodPressureMeasurementList = [self bloodPressureMeasurementsFromManagedBloodPressureData:managedBloodPressureMeasurementList];
    return bloodPressureMeasurementList;
}
-(BOOL)insertNewBloodPressureWithBloodPressureData:(BloodPressureData *)bloodPressure
{
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    ManagedBloodPressureData *managedBloodPressure = [NSEntityDescription insertNewObjectForEntityForName:@"bloodPressureMeasurement" inManagedObjectContext:currentManagedObjectContext];
    [self initialManagedBloodPressureData:managedBloodPressure withBloodPressureData:bloodPressure];
    NSError *error = nil;
    BOOL result = [currentManagedObjectContext save:&error];
    if (error) {
        
        NSLog(@"Fail to insert new bloodPressure with error:%@",[error description]);
        [currentManagedObjectContext rollback];
    }
    
    return result;
}
-(BOOL)deleteAllBloodPressureDataRecords
{
    BOOL result = NO;
    NSManagedObjectContext *currentManagedObjectContext = [[LFManagedDataContext shareManagedDataContext] currentManagedObjectContext];
    NSManagedObjectModel *currentManagedObjectModel = [[currentManagedObjectContext persistentStoreCoordinator] managedObjectModel];
    NSEntityDescription *bloodPressureEntity = [[currentManagedObjectModel entitiesByName]objectForKey:@"bloodPressureMeasurement"];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:bloodPressureEntity];
    NSError *error = nil;
    NSArray *managedBloodPressureMeasurementList = [currentManagedObjectContext executeFetchRequest:request error:&error];
    [request release];
    if (error) {
        
        NSLog(@"Fail to delete bloodPressure measurement by memberId with error:%@",[error description]);
        return result;
    }
    for (ManagedBloodPressureData *managedBloodPressure in managedBloodPressureMeasurementList) {
        
        [currentManagedObjectContext deleteObject:managedBloodPressure];
    }
    result = [currentManagedObjectContext save:&error];
    if (error) {
        
        NSLog(@"Fail to delete bloodPressure measurement with error:%@",[error description]);
        [currentManagedObjectContext rollback];
    }
    
    return  result;
}



@end
