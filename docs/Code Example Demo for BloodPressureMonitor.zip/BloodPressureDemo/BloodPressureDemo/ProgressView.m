//
//  ProgressView.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-27.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "ProgressView.h"

@interface ProgressView ()
{
    UILabel *label;
    NSString *labelText;
    UIFont *labelFont;
    CGRect boxRect;
    float margin;
}
@property(nonatomic,retain)NSString *labelText;
@property(nonatomic,retain)UIFont *labelFont;
@end

@implementation ProgressView
@synthesize labelText,labelFont;


-(void)setShowText:(NSString *)text
{
    label.text = text;
    [self setNeedsLayout];
    [self setNeedsDisplay];
}

-(void)appearInView:(UIView *)view
{
    [view addSubview:self];
    
}

-(void)disappearInView:(UIView *)view
{
    [self removeFromSuperview];
}
-(void)dealloc
{
    [labelFont release];
    [labelText release];
    [label release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.opaque = NO;
        self.backgroundColor = [UIColor clearColor];
        self.labelFont = [UIFont boldSystemFontOfSize:16];
        margin = 35;
        [self setupLabel];
    }
    return self;
}

-(void)setupLabel
{
 	label = [[UILabel alloc] initWithFrame:self.bounds];
	label.adjustsFontSizeToFitWidth = NO;
	label.textAlignment = NSTextAlignmentCenter;
	label.opaque = NO;
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [UIColor whiteColor];
    label.font = labelFont;
	label.text = self.labelText;
	[self addSubview:label];
}

-(void)layoutSubviews
{
    UIView *parent = self.superview;
    self.frame = parent.bounds;
    float maxWidth = self.bounds.size.width-4*margin;
    CGSize labelSize = [label.text sizeWithFont:labelFont];
    maxWidth = MAX(maxWidth, labelSize.width);
    boxRect = CGRectMake(0, 0, maxWidth, maxWidth);
    boxRect.origin.x = (self.bounds.size.width-maxWidth)/2;
    boxRect.origin.y = (self.bounds.size.height-maxWidth)/2;
    CGRect labelFrame ;
    
    labelFrame.size = labelSize;
    labelFrame.origin.x = (maxWidth-labelSize.width)/2+boxRect.origin.x;
    labelFrame.origin.y = (maxWidth-labelSize.height)/2+boxRect.origin.y;
    label.frame = labelFrame;
    
    
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    CGContextRef currentContext = UIGraphicsGetCurrentContext();
    UIGraphicsPushContext(currentContext);
    
    size_t gradLocationsNum = 2;
    CGFloat gradLocations[2] = {0.0f, 1.0f};
    CGFloat gradColors[8] = {0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.75f};
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradient = CGGradientCreateWithColorComponents(colorSpace, gradColors, gradLocations, gradLocationsNum);
    CGColorSpaceRelease(colorSpace);
    //Gradient center
    CGPoint gradCenter= CGPointMake(self.bounds.size.width/2, self.bounds.size.height/2);
    //Gradient radius
    float gradRadius = MIN(self.bounds.size.width , self.bounds.size.height) ;
    //Gradient draw
   CGContextDrawRadialGradient (currentContext, gradient, gradCenter,
                                 0, gradCenter, gradRadius,
                                 kCGGradientDrawsAfterEndLocation);
    CGGradientRelease(gradient);
    
    CGContextSetGrayFillColor(currentContext, 0.0, 0.8);
    
    float radius = 10.0f;
	CGContextBeginPath(currentContext);
	CGContextMoveToPoint(currentContext, CGRectGetMinX(boxRect) + radius, CGRectGetMinY(boxRect));
	CGContextAddArc(currentContext, CGRectGetMaxX(boxRect) - radius, CGRectGetMinY(boxRect) + radius, radius, 3 * (float)M_PI / 2, 0, 0);
	CGContextAddArc(currentContext, CGRectGetMaxX(boxRect) - radius, CGRectGetMaxY(boxRect) - radius, radius, 0, (float)M_PI / 2, 0);
	CGContextAddArc(currentContext, CGRectGetMinX(boxRect) + radius, CGRectGetMaxY(boxRect) - radius, radius, (float)M_PI / 2, (float)M_PI, 0);
	CGContextAddArc(currentContext, CGRectGetMinX(boxRect) + radius, CGRectGetMinY(boxRect) + radius, radius, (float)M_PI, 3 * (float)M_PI / 2, 0);
	CGContextClosePath(currentContext);
	CGContextFillPath(currentContext);
    
	UIGraphicsPopContext();
}


@end
