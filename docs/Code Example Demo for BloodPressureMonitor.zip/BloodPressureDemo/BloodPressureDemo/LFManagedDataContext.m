//
//  LFManagedDataContext.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "LFManagedDataContext.h"
#import <CoreData/CoreData.h>

@interface LFManagedDataContext ()
{
    NSManagedObjectContext *managedObjectContext;
}

@end

@implementation LFManagedDataContext

-(id)init
{
    if (self = [super init]) {
        
        managedObjectContext = [[NSManagedObjectContext alloc] init];
        [managedObjectContext setPersistentStoreCoordinator:[self persistentStoreCoordinator]];
    }
    
    return self;
}

-(NSManagedObjectContext *)currentManagedObjectContext
{
    return managedObjectContext;
}

-(NSEntityDescription *)deviceEntityDescription
{
    NSEntityDescription *deviceEntity = [[[NSEntityDescription alloc] init] autorelease];
    
    [deviceEntity setName:@"device"];
    [deviceEntity setManagedObjectClassName:@"LFManagedHardwareSensor"];
    
    NSAttributeDescription *maxUserQuantityAttribute = [[NSAttributeDescription alloc] init];
    [maxUserQuantityAttribute setName:@"maxUserQuantity"];
    [maxUserQuantityAttribute setAttributeType:NSInteger32AttributeType];
    [maxUserQuantityAttribute setOptional:NO];
    
    NSAttributeDescription *deviceIdAttribute = [[NSAttributeDescription alloc] init];
    [deviceIdAttribute setName:@"deviceId"];
    [deviceIdAttribute setAttributeType:NSStringAttributeType];
    [deviceIdAttribute setOptional:NO];
    
    NSAttributeDescription *snAttribute = [[NSAttributeDescription alloc] init];
    [snAttribute setName:@"deviceSn"];
    [snAttribute setAttributeType:NSStringAttributeType];
    [snAttribute setOptional:NO];
    
    NSAttributeDescription *deviceNameAttribute = [[NSAttributeDescription alloc] init];
    [deviceNameAttribute setName:@"sensorName"];
    [deviceNameAttribute setAttributeType:NSStringAttributeType];
    [deviceNameAttribute setOptional:NO];
    
    NSAttributeDescription *productTypeCodeAttribute = [[NSAttributeDescription alloc] init];
    [productTypeCodeAttribute setName:@"sensorType"];
    [productTypeCodeAttribute setAttributeType:NSInteger32AttributeType];
    [productTypeCodeAttribute setOptional:NO];
    
    NSAttributeDescription *modelNumAttribute = [[NSAttributeDescription alloc] init];
    [modelNumAttribute setName:@"modelNumber"];
    [modelNumAttribute setAttributeType:NSStringAttributeType];
    [modelNumAttribute setOptional:NO];
    
    NSAttributeDescription *softwareVersionAttribute = [[NSAttributeDescription alloc] init];
    [softwareVersionAttribute setName:@"softwareVersion"];
    [softwareVersionAttribute setAttributeType:NSStringAttributeType];
    [softwareVersionAttribute setOptional:YES];
    
    NSAttributeDescription *hardwareVersionAttribute = [[NSAttributeDescription alloc] init];
    [hardwareVersionAttribute setName:@"hardwareVersion"];
    [hardwareVersionAttribute setAttributeType:NSStringAttributeType];
    [hardwareVersionAttribute setOptional:YES];
    
    NSAttributeDescription *passwordAttribute = [[NSAttributeDescription alloc] init];
    [passwordAttribute setName:@"password"];
    [passwordAttribute setAttributeType:NSInteger32AttributeType];
    [passwordAttribute setOptional:NO];
    
    NSAttributeDescription *pairSignatureAttribute = [[NSAttributeDescription alloc] init];
    [pairSignatureAttribute setName:@"pairSignature"];
    [pairSignatureAttribute setAttributeType:NSInteger32AttributeType];
    [pairSignatureAttribute setOptional:NO];
    
    NSAttributeDescription *supportDownloadFeatureAttribute = [[NSAttributeDescription alloc] init];
    [supportDownloadFeatureAttribute setName:@"supportDownloadInfoFeature"];
    [supportDownloadFeatureAttribute setAttributeType:NSInteger32AttributeType];
    [supportDownloadFeatureAttribute setOptional:YES];
    
    NSAttributeDescription *manufactureNameAttribute = [[NSAttributeDescription alloc] init];
    [manufactureNameAttribute setName:@"manufactureName"];
    [manufactureNameAttribute setAttributeType:NSStringAttributeType];
    [manufactureNameAttribute setOptional:YES];
    
    NSAttributeDescription *firmwareVersionAttribute = [[NSAttributeDescription alloc] init];
    [firmwareVersionAttribute setName:@"firmwareVersion"];
    [firmwareVersionAttribute setAttributeType:NSStringAttributeType];
    [firmwareVersionAttribute setOptional:NO];
    
    NSAttributeDescription *systemIdAttribute = [[NSAttributeDescription alloc] init];
    [systemIdAttribute setName:@"systemId"];
    [systemIdAttribute setAttributeType:NSStringAttributeType];
    [systemIdAttribute setOptional:YES];

    
    NSMutableArray *propertyList = [[NSMutableArray alloc] init];
    [propertyList addObject:maxUserQuantityAttribute];
    [propertyList addObject:deviceIdAttribute];
    [propertyList addObject:snAttribute];
    [propertyList addObject:deviceNameAttribute];
    [propertyList addObject:productTypeCodeAttribute];
    [propertyList addObject:modelNumAttribute];
    [propertyList addObject:softwareVersionAttribute];
    [propertyList addObject:hardwareVersionAttribute];
    [propertyList addObject:passwordAttribute];
    [propertyList addObject:pairSignatureAttribute];
    [propertyList addObject:supportDownloadFeatureAttribute];
    [propertyList addObject:manufactureNameAttribute];
    [propertyList addObject:firmwareVersionAttribute];
    [propertyList addObject:systemIdAttribute];
    
    [deviceEntity setProperties:propertyList];
    [maxUserQuantityAttribute release];
    [deviceIdAttribute release];
    [snAttribute release];
    [deviceNameAttribute release];
    [productTypeCodeAttribute release];
    [modelNumAttribute release];
    [softwareVersionAttribute release];
    [hardwareVersionAttribute release];
    [passwordAttribute release];
    [pairSignatureAttribute release];
    [supportDownloadFeatureAttribute release];
    [manufactureNameAttribute release];
    [firmwareVersionAttribute release];
    [systemIdAttribute release];
    [propertyList release];
    
    return deviceEntity;
}

-(NSEntityDescription *)bloodPressureMeasurementEntity
{
    NSEntityDescription *bloodPressureEntity = [[[NSEntityDescription alloc] init] autorelease];
    [bloodPressureEntity setName:@"bloodPressureMeasurement"];
    [bloodPressureEntity setManagedObjectClassName:@"ManagedBloodPressureData"];
    
    NSAttributeDescription *systolicPressureAttribute = [[NSAttributeDescription alloc] init];
    [systolicPressureAttribute setName:@"systolic"];
    [systolicPressureAttribute setAttributeType:NSDoubleAttributeType];
    [systolicPressureAttribute setOptional:NO];
    
    NSAttributeDescription *diastolicPressureAttribute = [[NSAttributeDescription alloc] init];
    [diastolicPressureAttribute setName:@"diastolic"];
    [diastolicPressureAttribute setAttributeType:NSDoubleAttributeType];
    [diastolicPressureAttribute setOptional:NO];
    
    NSAttributeDescription *heartRateAttribute = [[NSAttributeDescription alloc] init];
    [heartRateAttribute setName:@"pluseRate"];
    [heartRateAttribute setAttributeType:NSDoubleAttributeType];
    [heartRateAttribute setOptional:NO];
    
    NSAttributeDescription *userNoAttribute = [[NSAttributeDescription alloc] init];
    [userNoAttribute setName:@"userNo"];
    [userNoAttribute setAttributeType:NSInteger32AttributeType];
    [userNoAttribute setOptional:YES];

    
    NSAttributeDescription *dateAttribute = [[NSAttributeDescription alloc] init];
    [dateAttribute setName:@"date"];
    [dateAttribute setAttributeType:NSStringAttributeType];
    [dateAttribute setOptional:NO];
    
    NSAttributeDescription *deviceIdAttribute = [[NSAttributeDescription alloc] init];
    [deviceIdAttribute setName:@"deviceId"];
    [deviceIdAttribute setAttributeType:NSStringAttributeType];
    [deviceIdAttribute setOptional:YES];
    
    NSAttributeDescription *unitAttribute = [[NSAttributeDescription alloc] init];
    [unitAttribute setName:@"unit"];
    [unitAttribute setAttributeType:NSStringAttributeType];
    [unitAttribute setOptional:NO];
    
    NSAttributeDescription *batteryAttribute = [[NSAttributeDescription alloc] init];
    [batteryAttribute setName:@"battery"];
    [batteryAttribute setAttributeType:NSInteger32AttributeType];
    [batteryAttribute setOptional:YES];
    
    NSMutableArray *propertyList = [[NSMutableArray alloc] init];
    [propertyList addObject:systolicPressureAttribute];
    [propertyList addObject:diastolicPressureAttribute];
    [propertyList addObject:heartRateAttribute];
    [propertyList addObject:userNoAttribute];
    [propertyList addObject:dateAttribute];
    [propertyList addObject:deviceIdAttribute];
    [propertyList addObject:unitAttribute];
    [propertyList addObject:batteryAttribute];
    
    [bloodPressureEntity setProperties:propertyList];
    
    [systolicPressureAttribute release];
    [diastolicPressureAttribute release];
    [heartRateAttribute release];
    [userNoAttribute release];
    [dateAttribute release];
    [deviceIdAttribute release];
    [unitAttribute release];
    [batteryAttribute release];
    [propertyList release];
    
    return bloodPressureEntity;
}

-(NSString*)persistenceStorePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [paths objectAtIndex:0];
    NSString *persistentPath = [documentPath stringByAppendingPathComponent:@"healthCenter_lifesense.db"];
    
    return persistentPath;
}

-(NSManagedObjectModel *)currentManagedObjectModel
{
    NSManagedObjectModel *localManagedObjectModel = [[[NSManagedObjectModel alloc] init] autorelease];
    NSEntityDescription *deviceEntity = [self deviceEntityDescription];

    NSEntityDescription *bloodPressureMeasurementEntity = [self bloodPressureMeasurementEntity];
    
    [localManagedObjectModel setEntities:[NSArray arrayWithObjects:deviceEntity,bloodPressureMeasurementEntity, nil]];
    
    return localManagedObjectModel;
    
}

-(NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
        
    NSPersistentStoreCoordinator * persistentStoreCoordinator = [[[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self currentManagedObjectModel]] autorelease];
    NSURL *storeURL = [NSURL fileURLWithPath:[self persistenceStorePath]];
    NSError *error = nil;
    NSPersistentStore *creatStore = [persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error];
    if (!creatStore) {
        
        NSLog(@"Store Configuration Failure with error:%@",[error localizedDescription]);
        persistentStoreCoordinator = nil;
    }
    
    return persistentStoreCoordinator;
}

static LFManagedDataContext *shareManagedDataContext = nil;

+(LFManagedDataContext *)shareManagedDataContext
{
    if (!shareManagedDataContext) {
        
        shareManagedDataContext = [[LFManagedDataContext alloc] init];
    }
    
    return shareManagedDataContext;
}

@end
