//
//  ViewController.m
//  BloodPressureDemo
//
//  Created by apple on 13-2-26.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import "ViewController.h"
#import "LFHardwareConnector.h"
#import "LFSensorDefine.h"
#import "LFDeviceDataStore.h"
#import "LFBloodPressureDataStore.h"
#import "ProgressView.h"
@interface ViewController ()<LFHardwareConnectorDelegate>
{
    NSMutableArray *sensorList;
    ProgressView *progress;
}
@end

@implementation ViewController
@synthesize sensorTable,typeLabel,dateLabel,dialLabel,label1,label2,deviceListButton;
-(void)dealloc
{
    [sensorList release];
    [sensorTable release];
    [typeLabel release];
    [dateLabel release];
    [dialLabel release];
    [label1 release];
    [label2 release];
    [deviceListButton release];
    [progress release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    sensorList = [[NSMutableArray alloc] init];
    sensorTable.delegate = self;
    sensorTable.dataSource = self;
    LFHardwareConnector *connector = [LFHardwareConnector shareConnector];
    [connector enalbeSensorType:LF_SENSOR_TYPE_BLOODPRESSURE];
    [connector setConnectorState:CONNECTOR_ANY_STATE];
    connector.delegate = self;
    [connector startScanning];
    progress = [[ProgressView alloc] initWithFrame:self.view.bounds];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)pairWithHardwareSensorSuccessDone
{
    [self performSegueWithIdentifier:@"DeviceList" sender:self];
}

-(void)startPairingProgress
{
    [progress setShowText:@"Pairing..."];
    [progress appearInView:self.view];
    deviceListButton.enabled = NO;
}

-(void)pairProgressDoneWithResult:(BOOL)result
{
    deviceListButton.enabled = YES;
    if (result) {
        
        [progress disappearInView:self.view];
        [self pairWithHardwareSensorSuccessDone];
    }else
    {
        [progress setShowText:@"Pairing Failed"];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        progress.alpha = 0.02f;
        [UIView commitAnimations];
        
    }
}

-(void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void*)context
{
    [progress disappearInView:self.view];
    deviceListButton.enabled = YES;
}

#pragma mark LFHardware connector delegate
-(void)hardwareConnectorDiscoveredSensor:(LFHardwareSensor *)sensor
{
    LFHardwareSensor *localSensor = [[LFDeviceDataStore shareDeviceDataStore] getSpecificDeviceInfoWithSignature:sensor.pairSignature];
    if (sensor.preparePair) {
        
        if (!localSensor) {
            
            [sensorList addObject:sensor];
            [sensorTable reloadData];
        }
        
    }else
    {
        if (localSensor) {
            
            sensor.deviceId = localSensor.deviceId;
            sensor.deviceSn = localSensor.deviceSn;
            sensor.sensorType = localSensor.sensorType;
            sensor.modelNumber = localSensor.modelNumber;
            sensor.sensorName = localSensor.sensorName;
            sensor.password = localSensor.password;
            sensor.supportDownloadInfoFeature = localSensor.supportDownloadInfoFeature;
            sensor.maxUserQuantity = localSensor.maxUserQuantity;
            sensor.softwareVersion = localSensor.softwareVersion;
            sensor.hardwareVersion = localSensor.hardwareVersion;
            sensor.firmwareVersion = localSensor.firmwareVersion;
            sensor.manufactureName = localSensor.manufactureName;
            sensor.systemId = localSensor.systemId;
            [[LFHardwareConnector shareConnector] enqueueHardwareSensor:sensor];
        }
    }
}

-(void)hardwareConnectorPairedSensor:(LFHardwareSensor *)sensor withState:(BOOL)state
{
    if (state) {
        
        [[LFDeviceDataStore shareDeviceDataStore] insertNewDeviceWithDeviceInfo:sensor];
        
    }
    [self pairProgressDoneWithResult:state];
}

-(void)hardwareConnectorReceiveBloodPressureMeasurementData:(BloodPressureData *)data
{
    self.typeLabel.text = [NSString stringWithFormat:@"bloodPressure"];
    self.dateLabel.text = data.date;
    self.dialLabel.text = [NSString stringWithFormat:@"%.1f/%.1f mmHg", data.systolic, data.diastolic];
    self.label1.text = [NSString stringWithFormat:@"pluse:%.1f",data.pluseRate];
    self.label2.text = [NSString stringWithFormat:@"userNo:%d", data.userNo];
    [[LFBloodPressureDataStore shareBloodPressureDataStore] insertNewBloodPressureWithBloodPressureData:data];
}

-(NSSet*)setOfDownloadInfoTypesForSensor:(LFHardwareSensor *)sensor
{
    /*if you set the download information type here which you want to write to the sensor device ,you must return this special information in the function 'hardwareConnectorGetDownloadInfoForSensor:',or there must happen to an crash */
    if ((sensor.supportDownloadInfoFeature&LF_DOWNLOAD_TYPE_SENSORINFO)&&sensor.preparePair)
    {
        return [NSSet setWithObject:[NSNumber numberWithInteger:LF_DOWNLOAD_TYPE_SENSORINFO]];
    }else
    {
        return nil;
    }
}

-(id)hardwareConnectorGetDownloadInfoForSensor:(LFHardwareSensor *)sensor ofInfoType:(LF_DOWNLOAD_INFO_TYPE)infoType
{
    /*which download type you set in function ,must return the information of type in this function*/
    if (infoType==LF_DOWNLOAD_TYPE_SENSORINFO&&sensor.preparePair) {
        
        SensorDownloadInfo *downloadInfo = [[[SensorDownloadInfo alloc] init] autorelease];
        uint8_t random = rand()%10;
        downloadInfo.sensorName = [NSString stringWithFormat:@"demo%d",random];
        sensor.sensorName = downloadInfo.sensorName;
        return downloadInfo;
    }else
    {
        return nil;
    }
}

-(void)hardwareConnectorDidDownloadInfoForSensor:(LFHardwareSensor *)sensor ofInfoType:(LF_DOWNLOAD_INFO_TYPE)infoType withResult:(BOOL)result
{
    if (infoType==LF_DOWNLOAD_TYPE_SENSORINFO&&result) {
        
        [[LFDeviceDataStore shareDeviceDataStore] updateDeviceWithDeviceInfo:sensor];
    }
}

#pragma mark tableView delegate and datasoure
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [sensorList count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"] autorelease];
    }
    LFHardwareSensor *sensor = [sensorList objectAtIndex:[indexPath row]];
    if (sensor) {
        
        cell.textLabel.text = sensor.modelNumber;
        cell.detailTextLabel.text = sensor.sensorName;
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LFHardwareSensor *sensor = [sensorList objectAtIndex:[indexPath row]];
    [[LFHardwareConnector shareConnector] pairWithHardwareSensor:sensor];
    [self startPairingProgress];
    [sensorList removeObject:sensor];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [tableView reloadData];
}
@end
